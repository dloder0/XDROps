function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\labsetup\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput


if (!(Test-Path -PathType Container -Path c:\tools\labsetup)) {
    New-Item -Path C:\Tools\labsetup -ItemType Directory
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

Set-DnsClientServerAddress 'Ether*' -ServerAddresses ('192.168.1.10')
Clear-DnsClientCache

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)
