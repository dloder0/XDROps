function CreateAuditOutput($MyText) {
	Out-File -filepath 'c:\tools\labsetup\setup.log' -Encoding default -Append -inputObject $MyText
} #CreateAuditOutput

if (!(Test-Path -PathType Container -Path c:\tools\labsetup)) {
    New-Item -Path C:\Tools\labsetup -ItemType Directory
}

$needReboot = $false

$Computername = $env:COMPUTERNAME
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup is continuing in " + $MyInvocation.MyCommand.Name)

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for startup task")
$Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
if ($null -eq $Task) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Startup task was not found")
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating startup task")
    $taskTrigger = New-ScheduledTaskTrigger -AtStartup
    $taskAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Tools\labsetup\$Computername.ps1" -WorkingDirectory 'c:\tools\labsetup'
    $taskPrincipal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $Task = Register-ScheduledTask 'ASDEFENDLABSETUP' -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal
}

Set-DnsClientServerAddress 'Ether*' -ServerAddresses ('192.168.1.10')
Clear-DnsClientCache

#CalderaAgent
CreateAuditOutput ("Checking for Caldera Agent")
if (Test-Path -Path "C:\Users\Public\splunkd.exe" -PathType Leaf) {
    CreateAuditOutput ("Found Caldera Agent")
} else {
    CreateAuditOutput ("Scheduling Caldera Agent installer script")
    $childScript = "C:\Tools\labsetup\Install-CalderaAgent.ps1"
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $childScript + '" -CreateSchedule'
    Start-Process -FilePath "powershell.exe" -ArgumentList $arguments -WindowStyle Hidden
}


#Directory
$SharePath = 'C:\Shares\Financials'
if (Test-Path -Path $SharePath -PathType Container){
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Found Directory at $SharePath")
} else {
    $needReboot = $true
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Directory at $SharePath")
    New-Item -ItemType Directory -Path $SharePath -Force
}

#Folder Permissions
$ACL = Get-Acl -Path $SharePath
$FoundACE = $false
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Everyone FullControl ACE on $SharePath")
ForEach ($ACE in $ACL.Access) {
    if ($ACE.IdentityReference -eq 'Everyone') {
        if ($Ace.FileSystemRights -eq 'FullControl') {
            $FoundACE = $true
        }
    }
}
if ($FoundACE) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Found Everyone FullControl ACE on $SharePath")
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Adding Everyone FullControl ACE on $SharePath")
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule('Everyone', 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
    $ACL.SetAccessRule($AccessRule)
    Set-Acl -Path $SharePath -AclObject $ACL
    $needReboot = $true
}

#Share
$ShareName = 'Financials'
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Share $ShareName")
$Share = Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue
if ($null -eq $Share) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Share $ShareName")
    New-SmbShare -Name $ShareName -Path $SharePath -FullAccess 'Everyone' -Description 'Anonymous Financials Share'
    $needReboot = $true
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Found Share $ShareName")
}

#InsecureGuestAuth
$Key = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation'
$Name = 'AllowInsecureGuestAuth'
$Type = 'DWord'
$Value = 1
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Registry Item $Key $Name")
$Item = $null
$Item = Get-ItemPropertyValue -Path $Key -Name $Name
if ($null -eq $Item) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Registry Item $Key $Name $Type $Value")
    if (!(Test-Path -Path $Key -PathType Container)) {
        New-Item -Path $Key
    }
    Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
    $needReboot = $true
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Registry Item $Key $Name current value is $Item")
    if ($Item -ne $Value) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setting Registry Item $Key $Name to $Value")
        Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
        $needReboot = $true
    }
}

#Everyone Include Anonymous
$Key = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
$Name = 'EveryoneIncludesAnonymous'
$Type = 'DWord'
$Value = 1
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Registry Item $Key $Name")
$Item = $null
$Item = Get-ItemPropertyValue -Path $Key -Name $Name
if ($null -eq $Item) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Registry Item $Key $Name $Type $Value")
    if (!(Test-Path -Path $Key -PathType Container)) {
        New-Item -Path $Key
    }
    Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
    $needReboot = $true
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Registry Item $Key $Name current value is $Item")
    if ($Item -ne $Value) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setting Registry Item $Key $Name to $Value")
        Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
        $needReboot = $true
    }
}

#Null Session Anonymous
$Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
$Name = 'RestrictNullSessAccess'
$Type = 'DWord'
$Value = 0
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Registry Item $Key $Name")
$Item = $null
$Item = Get-ItemPropertyValue -Path $Key -Name $Name
if ($null -eq $Item) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Registry Item $Key $Name $Type $Value")
    if (!(Test-Path -Path $Key -PathType Container)) {
        New-Item -Path $Key
    }
    Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
    $needReboot = $true
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Registry Item $Key $Name current value is $Item")
    if ($Item -ne $Value) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setting Registry Item $Key $Name to $Value")
        Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
        $needReboot = $true
    }
}

#NullSessionShares
$Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
$Name = 'NullSessionShares'
$Type = 'MultiString'
$Value = $ShareName
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Searching for Registry Item $Key $Name")
$Item = $null
$Item = Get-ItemPropertyValue -Path $Key -Name $Name
if ($null -eq $Item) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Creating Registry Item $Key $Name $Type $Value")
    if (!(Test-Path -Path $Key -PathType Container)) {
        New-Item -Path $Key
    }
    Set-ItemProperty -Path $Key -Name $Name -Type $Type -Value $Value
    $needReboot = $true
} else {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Registry Item $Key $Name current value is $Item")
}



$foundForest = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for forest")
    $Ping = Test-NetConnection -ComputerName 'contoso.local'
    if ($Ping.PingSucceeded) {
            $foundForest = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundForest))

$foundLDAP = $false
$loopcounter = 0
do {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Checking for domain controller response")
    $Ping = Test-NetConnection -ComputerName 'contoso.local' -Port 389
    if ($Ping.TcpTestSucceeded) {
            $foundLDAP = $true
    } else {
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    }
    Clear-DnsClientCache
} while (!($foundLDAP))

$CurrentDomain = (Get-WmiObject Win32_ComputerSystem).Domain
CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Current Domain is $CurrentDomain")
if ($CurrentDomain -eq 'contoso.local') {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joined to contoso.local")
} else {
    $joinCred = New-Object pscredential -ArgumentList ([pscustomobject]@{
        UserName = $null
        Password = (ConvertTo-SecureString -String 'TempJoinPA$$' -AsPlainText -Force)[0]
    })
    $addComputerSplat = @{
        DomainName = 'contoso.local'
        Options = 'UnsecuredJoin', 'PasswordPass'
        Credential = $joinCred
    }
    $loopcounter = 0
    $joinsucceeded = $false
    do {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Joining contoso.local")
        $Error.Clear()
        Add-Computer @addComputerSplat
        if ($Error.count -gt 0) {
            CreateAuditOutput ($Error[0].ToString())
        } else {
            $joinsucceeded = $true
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Join successful")
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
            $needReboot = $true
        }
        Start-Sleep -Seconds 10
        $loopcounter++
        if ($loopcounter -gt 100) {
            CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Exceeded wait period, rebooting")
            restart-computer -Force
            exit 1
        }
    } while (!($joinsucceeded))
}

CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Setup has ended in " + $MyInvocation.MyCommand.Name)

if ($needReboot) {
    CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Rebooting")
    restart-computer -Force
} else {
    $Task = Get-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -ErrorAction SilentlyContinue
    if ($null -ne $Task) {
        CreateAuditOutput ((get-date -UFormat "%Y.%m.%d.%H.%M.%S") + " Deleting setup task")
        Unregister-ScheduledTask -TaskName 'ASDEFENDLABSETUP' -Confirm:$false
    }
}
